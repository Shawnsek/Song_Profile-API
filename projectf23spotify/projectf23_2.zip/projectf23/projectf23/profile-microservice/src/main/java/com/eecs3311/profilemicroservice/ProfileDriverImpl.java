package com.eecs3311.profilemicroservice;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONException;
import org.json.JSONObject;
import org.neo4j.driver.v1.*;

import org.springframework.stereotype.Repository;

@Repository
public class ProfileDriverImpl implements ProfileDriver {

	Driver driver = ProfileMicroserviceApplication.driver;

	public static void InitProfileDb() {
		String queryStr;

		try (Session session = ProfileMicroserviceApplication.driver.session()) {
			try (Transaction trans = session.beginTransaction()) {
				queryStr = "CREATE CONSTRAINT ON (nProfile:profile) ASSERT exists(nProfile.userName)";
				trans.run(queryStr);

				queryStr = "CREATE CONSTRAINT ON (nProfile:profile) ASSERT exists(nProfile.password)";
				trans.run(queryStr);

				queryStr = "CREATE CONSTRAINT ON (nProfile:profile) ASSERT nProfile.userName IS UNIQUE";
				trans.run(queryStr);

				trans.success();
			} catch (Exception e) {
				if (e.getMessage().contains("An equivalent constraint already exists")) {
					System.out.println("INFO: Profile constraints already exist (DB likely already initialized), should be OK to continue");
				} else {
					// something else, yuck, bye
					throw e;
				}
			}
			session.close();
		}
	}

	@Override
	public DbQueryStatus createUserProfile(String userName, String fullName, String password) {
		String queryStr;
		Map<String, Object> params = new HashMap<>();
		params.put("userName", userName);
		params.put("fullName", fullName);
		params.put("password", password);
		params.put("plName", userName + "-favorites");

		try (Session session = driver.session()) {
			try (Transaction trans = session.beginTransaction()) {
				// Create a profile node
				queryStr = "CREATE (nProfile:profile {userName: $userName, fullName: $fullName, password: $password})";
				trans.run(queryStr, params);

				// Create a playlist node and establish a 'created' relationship
				queryStr = "MATCH (nProfile:profile {userName: $userName}) " +
						"CREATE (nPlaylist:playlist {plName: $plName}), " +
						"(nProfile)-[:created]->(nPlaylist)";
				trans.run(queryStr, params);

				trans.success();
				return new DbQueryStatus("User profile and playlist created successfully", DbQueryExecResult.QUERY_OK);
			} catch (Exception e) {
				if (e.getMessage().contains("already exists")) {
					return new DbQueryStatus("Username already exists", DbQueryExecResult.QUERY_ERROR_GENERIC);
				} else {
					return new DbQueryStatus("Error creating user profile and playlist: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
				}
			}
		} catch (Exception e) {
			return new DbQueryStatus("Error connecting to the database: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
		}
	}



	@Override
	public DbQueryStatus followFriend(String userName, String friendUserName) {
		String queryStr;
		Map<String, Object> params = new HashMap<>();
		params.put("userName", userName);
		params.put("frndUserName", friendUserName);

		try (Session session = driver.session()) {
			try (Transaction trans = session.beginTransaction()) {
				// Check if both users exist
				StatementResult userResult = trans.run("MATCH (user:profile {userName: $userName}) RETURN user", params);
				StatementResult friendResult = trans.run("MATCH (friend:profile {userName: $frndUserName}) RETURN friend", params);

				if (!userResult.hasNext()) {
					return new DbQueryStatus("User not found", DbQueryExecResult.QUERY_ERROR_NOT_FOUND);
				}

				if (!friendResult.hasNext()) {
					return new DbQueryStatus("Friend not found", DbQueryExecResult.QUERY_ERROR_NOT_FOUND);
				}

				// Create a relationship between the user and the friend
				queryStr = "MATCH (user:profile {userName: $userName}), (friend:profile {userName: $frndUserName}) " +
						"MERGE (user)-[:FOLLOWS]->(friend)";
				trans.run(queryStr, params);
				trans.success();

				return new DbQueryStatus("Successfully followed friend", DbQueryExecResult.QUERY_OK);
			} catch (Exception e) {
				return new DbQueryStatus("Error following friend: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
			}
		} catch (Exception e) {
			return new DbQueryStatus("Error connecting to the database: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
		}
	}


	@Override
	public DbQueryStatus unfollowFriend(String userName, String frndUserName) {
		String queryStr;
		Map<String, Object> params = new HashMap<>();
		params.put("userName", userName);
		params.put("frndUserName", frndUserName);

		try (Session session = driver.session()) {
			try (Transaction trans = session.beginTransaction()) {
				// Check if the user is currently following the friend
				queryStr = "MATCH (user:profile {userName: $userName})-[r:FOLLOWS]->(friend:profile {userName: $frndUserName}) RETURN r";
				StatementResult result = trans.run(queryStr, params);

				if (!result.hasNext()) {
					// No existing "follows" relationship found
					return new DbQueryStatus("User is not following the friend", DbQueryExecResult.QUERY_ERROR_NOT_FOUND);
				}

				// Remove the "follows" relationship
				queryStr = "MATCH (user:profile {userName: $userName})-[r:FOLLOWS]->(friend:profile {userName: $frndUserName}) DELETE r";
				trans.run(queryStr, params);
				trans.success();

				return new DbQueryStatus("Successfully unfollowed friend", DbQueryExecResult.QUERY_OK);
			} catch (Exception e) {
				return new DbQueryStatus("Error unfollowing friend: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
			}
		} catch (Exception e) {
			return new DbQueryStatus("Error connecting to the database: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
		}
	}


	@Override
	public DbQueryStatus getAllSongFriendsLike(String userName) {
		String queryStr;
		Map<String, Object> params = new HashMap<>();
		params.put("userName", userName);
		OkHttpClient httpClient = new OkHttpClient();

		try (Session session = driver.session()) {
			try (Transaction trans = session.beginTransaction()) {
				// Find all songs liked by friends of the user, along with the friend's username


				queryStr = "MATCH (user:profile {userName: $userName})-[:FOLLOWS]->(friend:profile)-[:created]->(playlist:playlist)-[:includes]->(song) " +
						"RETURN friend.userName AS friendUserName, collect(song.songId) AS songIds";
				StatementResult result = trans.run(queryStr, params);


				Map<String, List<String>> friendsSongs = new HashMap<>();
				while (result.hasNext()) {
					Record record = result.next();
					String friendUserName = record.get("friendUserName").asString();
					List<Object> friendSongIds = record.get("songIds").asList();

					List<String> songTitles = new ArrayList<>();
					System.out.println(friendSongIds);
					for (Object songId : friendSongIds) {
						// Call the song microservice to get the song title by ID
						String songTitle = getSongTitleById(songId.toString(), httpClient);
						if (songTitle != null) {
							songTitles.add(songTitle);
						}
					}

					friendsSongs.put(friendUserName, songTitles);
				}

				if (friendsSongs.isEmpty()) {
					return new DbQueryStatus("No songs liked by friends", DbQueryExecResult.QUERY_ERROR_NOT_FOUND);
				}

				DbQueryStatus dbQueryStatus = new DbQueryStatus("Successfully retrieved songs liked by friends", DbQueryExecResult.QUERY_OK);
				dbQueryStatus.setData(friendsSongs);
				return dbQueryStatus;
			} catch (Exception e) {
				return new DbQueryStatus("Error retrieving songs liked by friends: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
			}
		} catch (Exception e) {
			return new DbQueryStatus("Error connecting to the database: " + e.getMessage(), DbQueryExecResult.QUERY_ERROR_GENERIC);
		}
	}

	private String getSongTitleById(String songId, OkHttpClient client) {
		String songServiceUrl = "http://localhost:3001/getSongTitleById/" + songId;
		Request request = new Request.Builder()
				.url(songServiceUrl)
				.build();

		try (Response response = client.newCall(request).execute()) {
			String responseBody = response.body() != null ? response.body().string() : null;
			System.out.println("Request to Song Service: " + songServiceUrl);
			System.out.println("Response: " + responseBody);

			if (response.isSuccessful() && responseBody != null) {
				JSONObject jsonObject = new JSONObject(responseBody);
				return jsonObject.getString("data");
			}
		} catch (IOException e) {
			System.out.println("IOException when calling song service: " + e.getMessage());
		} catch (JSONException e) {
			System.out.println("JSONException when parsing response: " + e.getMessage());
		}
		return null;
	}






}
