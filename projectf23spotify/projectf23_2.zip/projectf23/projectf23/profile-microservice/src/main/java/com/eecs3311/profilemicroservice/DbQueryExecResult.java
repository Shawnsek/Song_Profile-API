package com.eecs3311.profilemicroservice;

public enum DbQueryExecResult {
	QUERY_OK,
	QUERY_ERROR_NOT_FOUND,
	QUERY_ERROR_GENERIC,
}
